Usage: "make compile"
