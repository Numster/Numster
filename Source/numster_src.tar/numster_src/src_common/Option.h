#ifndef OPTION_H
#define OPTION_H

#define NUC_HALF_SIZE 73
#define DEFAULT_NUC_WIDTH 147
#define NUC_MIN_WIDTH 120
#define NUC_MAX_WIDTH 160
#define UNPAIRED_NUC true
#define COMBINED_NUC false

#endif //OPTION_H
